
function jogar(escolhaDoJogador) {
    var opcoes = ['pedra', 'papel', 'tesoura'];
    var escolhaDoComputador = opcoes[Math.floor(Math.random() * 3)];

    if (escolhaDoJogador === escolhaDoComputador) {
        alert ('Empate!');
    } else if (
        (escolhaDoJogador === 'pedra' && escolhaDoComputador === 'tesoura') ||
        (escolhaDoJogador === 'papel' && escolhaDoComputador === 'pedra') ||
        (escolhaDoJogador === 'tesoura' && escolhaDoComputador === 'papel')
    ) {
        alert ('Você ganhou :)');
    } else {
        alert ('Você perdeu :(');
    }
}
